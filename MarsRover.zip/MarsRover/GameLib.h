//C4: Guard conditions
#ifndef GAMELIB_H
#define GAMELIB_H
//C2: Named constants
const int COMMAND_LINE_ERROR = -1;
const int CONVERSION_ERROR = -2;
//C2: Constants for tank orientation
const int UP = 0;
const int LEFT = 1;
const int RIGHT = 2;
const int DOWN = 3;
const int TERRAIN_MIN = 1;
const int TERRAIN_MAX = 5;

typedef int* intArray;
typedef intArray* int2DArray;
//C4: Use of programmer defined namespace
namespace gameLogicSpace
{
    //C3: Reduction of repetitive code
    int rangedRandom(int min, int max);
    int stringToInt(char* input);
    //C3: Task decomposition below...
    //C9: Allocating 2D Dynamic Array
    void createWorld(int2DArray& array, int numRows, int numCols);
    //C9: Initialising 2D Dynamic Array
    void initWorld(int2DArray array, int numRows, int numCols, int tankRow, int tankCol);
    //C9: Deallocating 2D Dynamic Array
    void destroyWorld(int2DArray& array, int numRows);
    //Finds out if there are any destructible blocks left
    bool terrainExists(int2DArray array, int numRows, int numCols);
    //C10: Correct Output
    void displayWorld(int2DArray array, int numRows, int numCols, int tankRow, int tankCol, int tankOrientation);
    void moveTank(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol, int tankOrientation);
    void fireShell(int2DArray array, int numRows, int numCols, int tankRow, int tankCol, int tankOrientation);
}
#endif
