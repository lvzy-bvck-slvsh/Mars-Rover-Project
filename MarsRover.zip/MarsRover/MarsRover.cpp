//C1: Library inclusion
#include <iostream>
#include <cstdlib>
#include <cassert>
#include <ctime>
#include <string>
#include "GameLib.h"

using namespace std;
using namespace gameLogicSpace;

const char* CLEAR_COMMAND = "cls";

int calcTankOrientation(int orientation, int direction) {
    if (direction == -1) {
        //TURN LEFT
        if (orientation == 3) {
            //DOWN
            orientation = 2;
        }
        else if (orientation == 0) {
            //UP
            orientation = 1;
        }
        else if (orientation == 1) {
            //LEFT
            orientation = 3;
        }
        else if (orientation == 2) {
            //RIGHT
            orientation = 0;
        }
    }
    else if (direction = 1) {
        //RIGHT
        if (orientation == 3) {
            orientation = 1;
        }
        else if (orientation == 0) {
            orientation = 2;
        }
        else if (orientation == 1) {
            orientation = 0;
        }
        else if (orientation == 2) {
            orientation = 3;
        }

    }
    return orientation;
}

int main(int argc, char** argv)
{
    srand(time(0));

    cout << "Enter number of Rovers : " << endl;
    int numRovers = 0;
    cin >> numRovers;

    int numRows = 0;
    int numCols = 0;
    int tankRow = 0;
    int tankCol = 0;
    char tankOrient;
    int tankOrientation = UP;
    const int UP = 0;
    const int LEFT = 1;
    const int RIGHT = 2;
    const int DOWN = 3;

    string cmd;

    if (numRovers > 0) {
        for (int n = 0; n < numRovers; n++) {
            cout << "Enter number of Rows :" << endl;
            cin >> numRows;
            cout << "Enter number of Cols:" << endl;
            cin >> numCols;
            cout << "Enter Rover Initial Row:" << endl;
            cin >> tankRow;
            cout << "Enter Rover Initial Col:" << endl;
            cin >> tankCol;
            cout << "Enter tank orientation: " << endl;
            cin >> tankOrient;

            cout << "Enter Rover Command: " << endl;
            cin >> cmd;

            if (tankOrient == 'N') {
                tankOrientation = UP;
            }
            else if (tankOrient == 'S') {
                tankOrientation = DOWN;
            }
            else if (tankOrient == 'W') {
                tankOrientation = LEFT;
            }
            else if (tankOrient == 'E') {
                tankOrientation = RIGHT;
            }
            else {
                cout << "Please enter an appropriate direction : N, E, S, W only" << endl;
                system("pause");
                return 0;
            }

            //check rover/tank boundaries:
            if (tankRow > numRows) {
                cout << "Rover out of bounds! " << tankRow << " > " << numRows << endl;
                system("pause");
                return 0;
            }
            if (tankCol > numCols) {
                cout << "Rover out of bounds! " << tankCol << " > " << numCols << endl;
                system("pause");
                return 0;
            }

            tankRow -= 1;
            tankCol -= 1;

            //Any orientation is fine to start
            int2DArray world = NULL;
            createWorld(world, numRows, numCols);
            initWorld(world, numRows, numCols, tankRow, tankCol);

            for (int i = 0; i < cmd.length(); i++) {
                //Clear the screen
                system(CLEAR_COMMAND);
                //Display the area
                displayWorld(world, numRows, numCols, tankRow, tankCol, tankOrientation);
                //C5: Menu System
                char choice = cmd[i];

                switch (choice)
                {
                case 'l':
                case 'L':
                    //TURN LEFT
                    if (tankOrientation == DOWN) {
                        //DOWN
                        tankOrientation = RIGHT;
                    }
                    else if (tankOrientation == UP) {
                        //UP
                        tankOrientation = LEFT;
                    }
                    else if (tankOrientation == LEFT) {
                        //LEFT
                        tankOrientation = DOWN;
                    }
                    else if (tankOrientation == RIGHT) {
                        //RIGHT
                        tankOrientation = UP;
                    }
                    break;
                case 'r':
                case 'R':
                    //TURN RIGHT
                    if (tankOrientation == DOWN) {
                        //DOWN
                        tankOrientation = LEFT;
                    }
                    else if (tankOrientation == UP) {
                        //UP
                        tankOrientation = RIGHT;
                    }
                    else if (tankOrientation == LEFT) {
                        //LEFT
                        tankOrientation = UP;
                    }
                    else if (tankOrientation == RIGHT) {
                        //RIGHT
                        tankOrientation = DOWN;
                    }
                    break;
                case 'm':
                case 'M':
                    moveTank(world, numRows, numCols, tankRow, tankCol, tankOrientation);
                    break;
                default:
                    cerr << "Invalid choice" << endl;
                }
            }
            //}
            destroyWorld(world, numRows);
        }
    }
    else {
        cout << "Number of Rovers needs to be greater than 0" << endl;
    }

    system("pause");
    return 0;
}
