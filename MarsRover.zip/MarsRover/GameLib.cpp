//C4: Inclusion of header file
#include "GameLib.h"
#include <iostream>
#include <cstdlib>
#include <sstream>
#include <cassert>
#include <string>
using namespace std;
namespace gameLogicSpace
{
    int rangedRandom(int min, int max)
    {
        //C7: Use of assertions
        assert(min < max);
        int result = 0;
        result = min + (rand() % (max - min + 1));
        return result;
    }

    int stringToInt(char* input)
    {
        int result = 0;
        stringstream stream;
        stream << input;
        stream >> result;
        if (stream.fail())
        {
            cerr << "Cannot convert " << input << " to an integer." << endl;
            exit(CONVERSION_ERROR);
        }
        return result;
    }

    void createWorld(int2DArray& array, int numRows, int numCols)
    {
        array = new intArray[numRows];
        for (int r = 0; r < numRows; r++)
        {
            array[r] = new int[numCols];
            for (int c = 0; c < numCols; c++)
            {
                array[r][c] = 0;
            }
        }
    }

    void initWorld(int2DArray array, int numRows, int numCols, int tankRow, int tankCol)
    {
        for (int r = 0; r < numRows; r++)
        {
            for (int c = 0; c < numCols; c++)
            {
                //We can't place terrain where the tank is
                if (r != tankRow && c != tankCol)
                {
                    /*
                    int chance = rangedRandom(1, 100);
                    if (chance <= TERRAIN_PROB)
                    {
                        array[r][c] = rangedRandom(TERRAIN_MIN, TERRAIN_MAX);
                    }
                    */
                }
            }
        }
    }

    void destroyWorld(int2DArray& array, int numRows)
    {
        for (int r = 0; r < numRows; r++)
        {
            delete[] array[r];
        }
        delete[] array;
        array = NULL;
    }

    bool terrainExists(int2DArray array, int numRows, int numCols)
    {
        for (int r = 0; r < numRows; r++)
        {
            for (int c = 0; c < numCols; c++)
            {
                if (array[r][c] > 0)
                {
                    //This is a block of terrain
                    return true;
                }
            }
        }
        return false;
    }

    void displayWorld(int2DArray array, int numRows, int numCols, int tankRow, int tankCol, int tankOrientation)
    {
        int tr = 0;
        int tc = 0;
        string to;
        //Go through each row and column, display the appropriate symbol
        for (int r = 0; r < numRows; r++)
        {
            for (int c = 0; c < numCols; c++)
            {
                //Output the tank in the appropriate row and column
                if (r == tankRow && c == tankCol)
                {
                    tr = r + 1;
                    tc = c + 1;
                    //Output based on orientation
                    switch (tankOrientation)
                    {
                    case UP:
                        cout << "^";
                        to = "N";
                        break;
                    case LEFT:
                        cout << "<";
                        to = "W";
                        break;
                    case RIGHT:
                        cout << ">";
                        to = "E";
                        break;
                    case DOWN:
                        cout << "v";
                        to = "S";
                        break;
                    }
                }
                /*
                else if (array[r][c] > 0)
                {
                    cout << "#";
                }
                */
                else if (array[r][c] == 0)
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
        cout << "[" << tr << " " << tc << " " << to << "]" << endl;
    }

    //Notice that the four movement functions ARE NOT listed in the header
    //This is so that the person using our library can only call moveTank
    void moveUp(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol)
    {
        //Check for out of bounds
        if (tankRow == 0)
        {
            //Don't do anything
            return;
        }
        //Check for terrain
        if (array[tankRow - 1][tankCol])
        {
            //Don't do anything
            return;
        }
        //We know it is safe to move, change our coordinates
        tankRow--;
    }

    void moveDown(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol)
    {
        //Check for out of bounds
        if (tankRow == numRows - 1)
        {
            //Don't do anything
            return;
        }
        //Check for terrain
        if (array[tankRow + 1][tankCol])
        {
            //Don't do anything
            return;
        }
        //We know it is safe to move, change our coordinates
        tankRow++;
    }

    void moveLeft(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol)
    {
        //Check for out of bounds
        if (tankCol == 0)
        {
            //Don't do anything
            return;
        }
        //Check for terrain
        if (array[tankRow][tankCol - 1])
        {
            //Don't do anything
            return;
        }
        //We know it is safe to move, change our coordinates
        tankCol--;
    }

    void moveRight(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol)
    {
        //Check for out of bounds
        if (tankCol == numCols - 1)
        {
            //Don't do anything
            return;
        }
        //Check for terrain
        if (array[tankRow][tankCol + 1])
        {
            //Don't do anything
            return;
        }
        //We know it is safe to move, change our coordinates
        tankCol++;
    }

    void moveTank(int2DArray array, int numRows, int numCols, int& tankRow, int& tankCol, int tankOrientation)
    {
        //Choose the appropriate function based on orientation
        switch (tankOrientation)
        {
        case UP:
            moveUp(array, numRows, numCols, tankRow, tankCol);
            break;
        case DOWN:
            moveDown(array, numRows, numCols, tankRow, tankCol);
            break;
        case LEFT:
            moveLeft(array, numRows, numCols, tankRow, tankCol);
            break;
        case RIGHT:
            moveRight(array, numRows, numCols, tankRow, tankCol);
            break;
        }
    }

    void fireShell(int2DArray array, int numRows, int numCols, int tankRow, int tankCol, int tankOrientation)
    {
        //Firing depends on orientation
        switch (tankOrientation)
        {
        case UP:
            //Check the rows upwards of the tank
            for (int r = tankRow - 1; r >= 0; r--)
            {
                if (array[r][tankCol] > 0)
                {
                    array[r][tankCol]--;
                    break;
                }
            }
            break;
        case DOWN:
            //Check the rows below the tank
            for (int r = tankRow + 1; r < numRows; r++)
            {
                if (array[r][tankCol] > 0)
                {
                    array[r][tankCol]--;
                    break;
                }
            }
            break;
        case LEFT:
            for (int c = tankCol - 1; c >= 0; c--)
            {
                if (array[tankRow][c] > 0)
                {
                    array[tankRow][c]--;
                    break;
                }
            }
            break;
        case RIGHT:
            for (int c = tankCol + 1; c < numCols; c++)
            {
                if (array[tankRow][c] > 0)
                {
                    array[tankRow][c]--;
                    break;
                }
            }
            break;
        }
    }
}
